package com.example.wildlife;  // Use your app's package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class kokmote extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kokmote); // Ensure this is your XML file's correct name

        // Find the Book Now button and set an onClick listener to navigate to LoginActivity
        Button bookNowButton = findViewById(R.id.bookNowButton);
        bookNowButton.setOnClickListener(v -> {
            Intent intent = new Intent(kokmote.this, calender2.class);
            startActivity(intent);
        });

        // Initialize Bottom Navigation View
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Handle item selection on the Bottom Navigation Bar
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {

            if (item.getItemId() == R.id.map) {
                Intent intent = new Intent(kokmote.this, map.class);
                startActivity(intent);
                return true;
            }

            if (item.getItemId() == R.id.home) {
                Intent intent = new Intent(kokmote.this, home.class);
                startActivity(intent);
                return true;
            }

            if (item.getItemId() == R.id.warning) {
                Intent intent = new Intent(kokmote.this, ReportActivity.class);
                startActivity(intent);
                return true;
            }

            if (item.getItemId() == R.id.profile) {
                if (!UserPreferences.isSignedUp()) {
                    // Navigate to the sign-up activity if not signed up
                    Intent intent = new Intent(kokmote.this, sign_up.class);
                    startActivity(intent);
                } else if (!UserPreferences.isLoggedIn()) {
                    // Navigate to the login activity if signed up but not logged in
                    Intent intent = new Intent(kokmote.this, sign_up.class);
                    startActivity(intent);
                } else {
                    // Navigate to the Profile activity if logged in
                    Intent intent = new Intent(kokmote.this, sign_up.class);
                    startActivity(intent);
                }
                return true; // Ensure it returns true for successful navigation
            }
            return false; // Default return if none of the conditions are met
        });
    }
}
