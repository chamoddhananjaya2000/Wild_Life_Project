package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class loginpage extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private TextView tvSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginpage);  // Ensure loginpage.xml exists in the layout folder

        // Initialize UI elements
        usernameEditText = findViewById(R.id.emailaccount);
        passwordEditText = findViewById(R.id.passwordlogin);
        loginButton = findViewById(R.id.login1);
        tvSignup = findViewById(R.id.tvSignup);  // Make sure this TextView exists in loginpage.xml

        // Set click listener for login button
        loginButton.setOnClickListener(v -> loginUser());

        // Set click listener for "Sign Up" text
        tvSignup.setOnClickListener(v -> {
            Intent intent = new Intent(loginpage.this, sign_up.class);
            startActivity(intent);
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {

            if (item.getItemId() == R.id.map) {
                Intent intent = new Intent(loginpage.this, map.class);
                startActivity(intent);
                return true;
            }

            if (item.getItemId() == R.id.home) {
                Intent intent = new Intent(loginpage.this, home.class);
                startActivity(intent);
                return true;
            }

            if (item.getItemId() == R.id.warning) {
                Intent intent = new Intent(loginpage.this, ReportActivity.class);
                startActivity(intent);
                return true;
            }
            if (item.getItemId() == R.id.profile) {
                Intent intent = new Intent(loginpage.this, sign_up.class);
                startActivity(intent);
                return true;
            }
            return false;
        });

    }

    // Login validation logic
    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(loginpage.this, "Please enter your username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Hardcoded credentials for validation
        String correctUsername = "pasinduthambugala@gmail.com";
        String correctPassword = "1234";

        if (username.equals(correctUsername) && password.equals(correctPassword)) {
            Toast.makeText(loginpage.this, "Login Successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(loginpage.this, payment.class);  // Redirect to home instead of payment
            startActivity(intent);
            finish();  // Closes the login activity
        } else {
            Toast.makeText(loginpage.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

    }
}
