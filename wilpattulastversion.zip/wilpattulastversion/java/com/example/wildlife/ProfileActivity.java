package com.example.wildlife;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ProfileActivity extends AppCompatActivity {

    private ImageView profileImage;
    private Button btnChangeProfilePic;
    private TextView tvUsername;
    private TextView emailaccount;
    private Button btnLogout;
    private BottomNavigationView bottomNavigationView;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile);  // Make sure the layout name matches your XML

        // Initialize Views
        profileImage = findViewById(R.id.profile_image);
        btnChangeProfilePic = findViewById(R.id.btnChangeProfilePic);
        tvUsername = findViewById(R.id.tvUsername);
        emailaccount = findViewById(R.id.emailaccount);
        btnLogout = findViewById(R.id.btnLogout);


        // Set the default values (you can replace them with dynamic data)
        tvUsername.setText("Chamod Dhananjaya");
        emailaccount.setText("chamoddhananjaya2000@gmail.com");

        // Handle Change Profile Picture button click
        btnChangeProfilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logic to change the profile picture (e.g., open a gallery)
                // For now, just set a new image (you can add your logic here)
                profileImage.setImageResource(R.drawable.imagesicon);  // Replace with actual image
            }
        });

        // Handle Logout button click
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logout functionality (e.g., clear user session and go to login screen)
                // For now, just finish the activity to simulate logout
                finish();
            }
        });


    }
}
