package com.example.wildlife;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AttractionAdapter extends RecyclerView.Adapter<AttractionAdapter.AttractionViewHolder> {

    private List<Attraction> attractions;

    public AttractionAdapter(List<Attraction> attractions) {
        this.attractions = attractions;
    }

    @Override
    public AttractionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the item layout for the attraction
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_attraction, parent, false);
        return new AttractionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AttractionViewHolder holder, int position) {
        Attraction attraction = attractions.get(position);

        // Set the name of the attraction
        holder.nameTextView.setText(attraction.getName());

        // Set the description of the attraction
        holder.descriptionTextView.setText(attraction.getDescription());

        // Load the image from the resources and set it to the ImageView
        holder.imageView.setImageResource(attraction.getImageResId());
    }

    @Override
    public int getItemCount() {
        return attractions.size();
    }

    public static class AttractionViewHolder extends RecyclerView.ViewHolder {

        public TextView nameTextView;
        public TextView descriptionTextView;
        public ImageView imageView;

        public AttractionViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.attraction_name); // TextView for name
            descriptionTextView = itemView.findViewById(R.id.attraction_description); // TextView for description
            imageView = itemView.findViewById(R.id.attraction_image); // ImageView for image
        }
    }
}
