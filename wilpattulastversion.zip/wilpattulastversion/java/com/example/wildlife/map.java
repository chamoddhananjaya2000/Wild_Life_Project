package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class map extends AppCompatActivity {

    private ImageView mapImageView;
    private ScaleGestureDetector scaleGestureDetector;
    private float scaleFactor = 1f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);

        mapImageView = findViewById(R.id.mapImageView);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Initialize ScaleGestureDetector
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());

        // ✅ Correct: Set listener inside onCreate()
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.map) {
                startActivity(new Intent(map.this, map.class));
                return true;
            }
            if (id == R.id.home) {
                startActivity(new Intent(map.this, home.class));
                return true;
            }
            if (id == R.id.warning) {
                startActivity(new Intent(map.this, ReportActivity.class));
                return true;
            }
            if (id == R.id.profile) {
                startActivity(new Intent(map.this, sign_up.class));
                return true;
            }
            return false;
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    // ✅ Correct: Move ScaleListener outside bottom navigation logic
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(@NonNull ScaleGestureDetector detector) {
            scaleFactor *= detector.getScaleFactor();
            scaleFactor = Math.max(0.1f, Math.min(scaleFactor, 5.0f));

            mapImageView.setScaleX(scaleFactor);
            mapImageView.setScaleY(scaleFactor);

            return true;
        }
    }
}
