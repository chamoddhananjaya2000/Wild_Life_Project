package com.example.wildlife;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "wildlife.db";

    private static final String TABLE_REPORTS = "reports";

    private static final String COLUMN_REPORT_ID = "id";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_IMAGE = "image";

    private static final String CREATE_TABLE_REPORTS = "CREATE TABLE " + TABLE_REPORTS + "("
            + COLUMN_REPORT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_DESCRIPTION + " TEXT, "
            + COLUMN_IMAGE + " BLOB" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_REPORTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        onCreate(db);
    }

    // Add a report to the database
    public long addReport(String description, byte[] image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_IMAGE, image);
        long result = db.insert(TABLE_REPORTS, null, values);
        db.close();
        return result;
    }

    // Get all reports from the database
    @SuppressLint("Range")
    public List<Report> getAllReports() {
        List<Report> reports = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_REPORTS;
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Report report = new Report();
                report.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_REPORT_ID)));
                report.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
                report.setImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_IMAGE)));
                reports.add(report);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reports;
    }

    // Get a report by its ID
    @SuppressLint("Range")
    public Report getReportById(int reportId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_ID + " = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(reportId)});

        if (cursor != null && cursor.moveToFirst()) {
            Report report = new Report();
            report.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_REPORT_ID)));
            report.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
            report.setImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_IMAGE)));
            cursor.close();
            db.close();
            return report;
        }
        cursor.close();
        db.close();
        return null;
    }

    // Update the report status (e.g., for accepting or rejecting the report)
    public boolean updateReportStatus(int reportId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESCRIPTION, status); // You can store status in the description field for simplicity
        int rowsUpdated = db.update(TABLE_REPORTS, values, COLUMN_REPORT_ID + " = ?", new String[]{String.valueOf(reportId)});
        db.close();
        return rowsUpdated > 0;
    }

    // Delete a report from the database
    public boolean deleteReport(int reportId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_REPORTS, COLUMN_REPORT_ID + " = ?", new String[]{String.valueOf(reportId)});
        db.close();
        return rowsDeleted > 0;
    }
}
