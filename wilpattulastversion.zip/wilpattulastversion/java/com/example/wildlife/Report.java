package com.example.wildlife;

public class Report {
    private int id;
    private String description;
    private byte[] image;
    private String approvalStatus;  // Field for approval status

    // Constructor
    public Report() {
    }

    public Report(int id, String description, byte[] image, String approvalStatus) {
        this.id = id;
        this.description = description;
        this.image = image;
        this.approvalStatus = approvalStatus;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    // Custom method to get Report ID for consistency with the database helper
    public int getReportId() {
        return this.id;
    }
}
