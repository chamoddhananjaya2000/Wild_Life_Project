// BungalowBookingActivity.java
package com.example.wildlife;  // Use your app's package name

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class elephant extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.elephant);  // This should match the name of your XML layout


    }
}
