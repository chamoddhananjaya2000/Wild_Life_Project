package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.Task;

public class sign_up extends AppCompatActivity {

    private static final int RC_SIGN_IN = 100;

    private EditText etUsername, etEmail, etPassword;
    private Button btnSignUp;
    private SignInButton btnGoogleSignIn;
    private TextView tvAlreadyHaveAccount;

    private GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up); // Replace with your layout XML file

        // Initialize views
        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnGoogleSignIn = findViewById(R.id.btnGoogleSignIn);
        tvAlreadyHaveAccount = findViewById(R.id.tvAlreadyHaveAccount);

        // Set up Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Set up listeners
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSignUp();
            }
        });

        btnGoogleSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleGoogleSignIn();
            }
        });

        tvAlreadyHaveAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSignIn();
            }
        });
    }

    private void handleSignUp() {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Basic validation
        if (username.isEmpty()) {
            etUsername.setError("Username is required");
            return;
        }
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            return;
        }
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            return;
        }

        // Proceed with Sign Up logic (e.g., Firebase, API call, etc.)
        // Here, just show a Toast message as a placeholder
        Toast.makeText(sign_up.this, "Sign Up successful", Toast.LENGTH_SHORT).show();

        // After successful sign up, navigate to ProfileActivity
        Intent intent = new Intent(sign_up.this, ProfileActivity.class);
        startActivity(intent);
        finish();  // Optional: Finish SignUpActivity to prevent the user from coming back
    }

    private void handleGoogleSignIn() {
        // Use Google Sign-In API to sign in
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void navigateToSignIn() {
        // Navigate to the Sign In activity
        Intent intent = new Intent(sign_up.this, ProfileActivity.class);  // Change to your SignInActivity if needed
        startActivity(intent);
        finish();  // Optional: Finish SignUpActivity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            // The Google Sign-In API returns the result here
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            // Signed in successfully, show authenticated UI
            GoogleSignInAccount account = completedTask.getResult();
            Toast.makeText(this, "Signed in as " + account.getDisplayName(), Toast.LENGTH_SHORT).show();
            // You can proceed with the user's account info, like account.getEmail(), account.getId(), etc.
        } catch (Exception e) {
            // Sign-in failed, handle the failure
            Toast.makeText(this, "Sign-in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
