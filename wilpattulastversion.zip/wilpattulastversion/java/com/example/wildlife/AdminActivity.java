package com.example.wildlife;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.net.Uri;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class AdminActivity extends AppCompatActivity {

    private TextView reportDescriptionTextView;
    private ImageView reportImageView;
    private Button btnAcceptReport, btnDeleteReport, btnSaveImage;
    private DatabaseHelper databaseHelper;
    private Report currentReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Initialize views
        reportDescriptionTextView = findViewById(R.id.report_description_text_view);
        reportImageView = findViewById(R.id.report_image_view);
        btnAcceptReport = findViewById(R.id.btn_accept_report);
        btnDeleteReport = findViewById(R.id.btn_delete_report);
        btnSaveImage = findViewById(R.id.btn_save_image);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load the reports from the database
        List<Report> reports = databaseHelper.getAllReports();

        // Check if reports are retrieved
        if (reports.isEmpty()) {
            reportDescriptionTextView.setText("No reports available");
        } else {
            // Assuming you want to display the first report
            currentReport = reports.get(0); // Get the first report or iterate over them

            // Set the description
            String description = currentReport.getDescription();
            if (description != null && !description.isEmpty()) {
                reportDescriptionTextView.setText(description);
            } else {
                reportDescriptionTextView.setText("No description available");
            }

            // Convert byte array to Bitmap for the image
            byte[] imageBytes = currentReport.getImage();
            if (imageBytes != null && imageBytes.length > 0) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                reportImageView.setImageBitmap(bitmap);
            } else {
                reportImageView.setImageResource(R.drawable.imagesicon); // Placeholder in case of no image
            }
        }

        // Handle Accept Report Button Click
        btnAcceptReport.setOnClickListener(v -> acceptReport());

        // Handle Delete Report Button Click
        btnDeleteReport.setOnClickListener(v -> deleteReport());

        // Handle Save Image Button Click
        btnSaveImage.setOnClickListener(v -> {
            // Save the image to the gallery
            if (currentReport != null && currentReport.getImage() != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(currentReport.getImage(), 0, currentReport.getImage().length);
                saveImageToGallery(bitmap);
            }
        });
    }

    // Method to accept the report
    private void acceptReport() {
        if (currentReport != null) {
            // Mark the report as accepted (approved) in the database
            currentReport.setApprovalStatus("Accepted");

            // Update the report status in the database
            boolean result = databaseHelper.updateReportStatus(currentReport.getReportId(), "Accepted");

            if (result) {
                Toast.makeText(this, "Report accepted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to accept report", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to delete the report
    private void deleteReport() {
        if (currentReport != null) {
            // Delete the report from the database
            boolean result = databaseHelper.deleteReport(currentReport.getReportId());

            if (result) {
                Toast.makeText(this, "Report deleted", Toast.LENGTH_SHORT).show();
                // Clear the views or go to another activity
                reportDescriptionTextView.setText("No reports available");
                reportImageView.setImageResource(R.drawable.imagesicon); // Set to a placeholder
            } else {
                Toast.makeText(this, "Failed to delete report", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Save image to the gallery
    private void saveImageToGallery(Bitmap bitmap) {
        // Prepare the content values to store the image in the gallery
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, "Report Image");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Image from Report");
        contentValues.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        // Save the image to the gallery
        try {
            // Get the content resolver and insert the image
            Uri imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            try (FileOutputStream outputStream = (FileOutputStream) getContentResolver().openOutputStream(imageUri)) {
                // Compress the bitmap and write it to the output stream
                if (bitmap != null) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.flush();
                    Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
        }
    }
}
