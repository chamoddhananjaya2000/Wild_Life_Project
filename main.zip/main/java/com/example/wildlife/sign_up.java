package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class sign_up extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnSignUp;

    private UserPreferences userPreferences;
    private GoogleSignInClient googleSignInClient;
    private static final int RC_SIGN_IN = 9001;  // Request code for Google Sign-In

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnSignUp = findViewById(R.id.btnSignUp);
        Button btnGoogleSignIn = findViewById(R.id.btnGoogleSignIn);

        userPreferences = new UserPreferences(this);

        // Google Sign-In configuration
        googleSignInClient = GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN);

        btnSignUp.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                // Save sign-up state
                userPreferences.setSignedUp(true);
                Toast.makeText(sign_up.this, "Sign-up successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(sign_up.this, login.class));
                finish();
            } else {
                Toast.makeText(sign_up.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        // Google Sign-In Button Clicked
        btnGoogleSignIn.setOnClickListener(v -> signInWithGoogle());
    }

    // Google Sign-In process
    private void signInWithGoogle() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    // Handle Google Sign-In result
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                // Signed in successfully, show authenticated UI
                String username = account.getDisplayName();
                userPreferences.setSignedUp(true);  // Assuming successful sign-in
                Toast.makeText(sign_up.this, "Sign-up with Google successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(sign_up.this, sign_up.class));
                finish();
            } catch (ApiException e) {
                Toast.makeText(sign_up.this, "Google sign-in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
