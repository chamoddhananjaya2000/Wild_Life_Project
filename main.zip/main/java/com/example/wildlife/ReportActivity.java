package com.example.wildlife;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ReportActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText reportDescription;
    private ImageView imagePreview;
    private Uri imageUri;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report);

        // Initialize views
        reportDescription = findViewById(R.id.report_description);
        imagePreview = findViewById(R.id.image_preview);
        Button uploadImageButton = findViewById(R.id.btn_upload_image);
        Button submitReportButton = findViewById(R.id.btn_submit_report);

        // Firebase Database & Storage References
        databaseReference = FirebaseDatabase.getInstance().getReference("reports");
        storageReference = FirebaseStorage.getInstance().getReference("report_images");

        // Set onClick listeners
        uploadImageButton.setOnClickListener(v -> openGallery());
        submitReportButton.setOnClickListener(v -> submitReport());
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            imageUri = data.getData();
            imagePreview.setVisibility(View.VISIBLE);
            imagePreview.setImageURI(imageUri);
        }
    }

    private void submitReport() {
        String description = reportDescription.getText().toString().trim();

        // Check if the description is empty
        if (description.isEmpty()) {
            reportDescription.setError("Description required");
            return;
        }

        // Check if an image has been selected
        if (imageUri != null) {
            // Upload Image to Firebase Storage
            StorageReference fileRef = storageReference.child(System.currentTimeMillis() + ".jpg");
            fileRef.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String imageUrl = uri.toString();
                        String reportId = databaseReference.push().getKey();

                        // Create a report object
                        ReportModel report = new ReportModel(reportId, description, imageUrl, "pending");

                        // Save the report in Firebase Database
                        databaseReference.child(reportId).setValue(report).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                // Pass the data to AdminActivity
                                Intent intent = new Intent(ReportActivity.this, AdminActivity.class);
                                intent.putExtra("report_description", description);
                                intent.putExtra("report_image_url", imageUrl);
                                intent.putExtra("report_id", reportId);

                                startActivity(intent); // Start AdminActivity

                                // Show success message
                                Toast.makeText(ReportActivity.this, "Report Successfully Submitted", Toast.LENGTH_SHORT).show();

                                finish(); // Close ReportActivity after submission
                            } else {
                                Toast.makeText(ReportActivity.this, "Submission Failed", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }))
                    .addOnFailureListener(e -> {
                        // Handle any errors during image upload
                        Toast.makeText(ReportActivity.this, "Image Upload Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(this, "Please upload an image", Toast.LENGTH_SHORT).show();
        }
    }
}
