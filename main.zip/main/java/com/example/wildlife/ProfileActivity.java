package com.example.wildlife;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvUsername;

    private UserPreferences userPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvUsername = findViewById(R.id.tvUsername);

        userPreferences = new UserPreferences(this);

        // Display user information (For demonstration, just showing the username)
        String username = "User"; // You can replace this with the actual username if saved
        tvUsername.setText("Welcome, " + username);
    }
}
