package com.example.wildlife;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class map extends AppCompatActivity {

    private ImageView mapImageView;
    private ScaleGestureDetector scaleGestureDetector;
    private float scaleFactor = 1f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);

        mapImageView = findViewById(R.id.mapImageView);

        // Initialize the ScaleGestureDetector
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Let the ScaleGestureDetector handle the touch event
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }

    // Inner class to handle scaling events
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            // Get the scale factor and apply it to the ImageView
            scaleFactor *= detector.getScaleFactor();
            scaleFactor = Math.max(0.1f, Math.min(scaleFactor, 5.0f));  // Limit the zoom range (0.1 to 5.0)

            // Apply scaling transformation to the ImageView using a matrix
            mapImageView.setScaleX(scaleFactor);
            mapImageView.setScaleY(scaleFactor);

            return true;
        }
    }
}
