package com.example.wildlife;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class calender extends AppCompatActivity {

    private CalendarView calendarView;
    private TextView selectedDateText, ticketQuantityText, totalPriceText;
    private Button btnMinus, btnPlus, btnBuyTicket;

    private int ticketQuantity = 1;
    private int ticketPrice = 80;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calender);

        // Initialize views
        calendarView = findViewById(R.id.calendarView);
        selectedDateText = findViewById(R.id.selectedDateText);
        ticketQuantityText = findViewById(R.id.ticketQuantity);
        totalPriceText = findViewById(R.id.total);
        btnMinus = findViewById(R.id.btnMinus);
        btnPlus = findViewById(R.id.btnPlus);
        btnBuyTicket = findViewById(R.id.btnBuyTicket);

        // Set default selected date
        updateSelectedDateText(Calendar.getInstance());

        // Set listener for date change in CalendarView
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(year, month, dayOfMonth);
            updateSelectedDateText(selectedCalendar);
        });

        // Set listener for the minus button (decrease ticket quantity)
        btnMinus.setOnClickListener(v -> {
            if (ticketQuantity > 1) {
                ticketQuantity--;
                updateTicketQuantity();
            }
        });

        // Set listener for the plus button (increase ticket quantity)
        btnPlus.setOnClickListener(v -> {
            ticketQuantity++;
            updateTicketQuantity();
        });

        // Set listener for the buy ticket button
        btnBuyTicket.setOnClickListener(v -> {
            // Check if the user is logged in
            if (isUserLoggedIn()) {
                // If the user is logged in, navigate to the payment page
                Intent intent = new Intent(calender.this, payment.class);
                startActivity(intent);
            } else {
                // If the user is not logged in, navigate to the login page
                Intent intent = new Intent(calender.this, login.class);
                startActivity(intent);
            }
        });
    }

    // Method to update the selected date text
    private void updateSelectedDateText(Calendar calendar) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
        String formattedDate = sdf.format(calendar.getTime());
        selectedDateText.setText("Selected Date: " + formattedDate);
    }

    // Method to update the ticket quantity and total price
    private void updateTicketQuantity() {
        ticketQuantityText.setText(String.valueOf(ticketQuantity));
        int totalPrice = ticketQuantity * ticketPrice;
        totalPriceText.setText("Total\nRS " + totalPrice);
    }

    // Method to check if the user is logged in using SharedPreferences
    private boolean isUserLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        return sharedPreferences.getBoolean("isLoggedIn", false); // Default to false if not logged in
    }
}
