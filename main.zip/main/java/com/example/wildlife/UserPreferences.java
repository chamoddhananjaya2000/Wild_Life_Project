package com.example.wildlife;

import android.content.Context;
import android.content.SharedPreferences;

public class UserPreferences {

    private static final String PREF_NAME = "user_preferences";
    private static final String KEY_IS_SIGNED_UP = "is_signed_up";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";

    private static SharedPreferences sharedPreferences;

    public UserPreferences(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void setSignedUp(boolean isSignedUp) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_IS_SIGNED_UP, isSignedUp);
        editor.apply();
    }

    public static boolean isSignedUp() {
        return sharedPreferences.getBoolean(KEY_IS_SIGNED_UP, false);
    }

    public void setLoggedIn(boolean isLoggedIn) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    public static boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }
}
