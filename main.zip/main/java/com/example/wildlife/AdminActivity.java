package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class AdminActivity extends AppCompatActivity {

    private TextView reportDescriptionText;
    private ImageView reportImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);  // Ensure this is the correct layout

        // Initialize views
        reportDescriptionText = findViewById(R.id.report_description_text);  // Ensure correct ID in XML
        reportImageView = findViewById(R.id.report_image_view);  // Ensure correct ID in XML

        // Get the data passed from ReportActivity
        Intent intent = getIntent();
        String description = intent.getStringExtra("report_description");
        String imageUrl = intent.getStringExtra("report_image_url");

        if (description != null) {
            reportDescriptionText.setText(description);
        } else {
            Toast.makeText(this, "No description available", Toast.LENGTH_SHORT).show();
        }

        // Load the image using Glide
        if (imageUrl != null) {
            Glide.with(this)
                    .load(imageUrl)  // Use the image URL received
                    .into(reportImageView);  // Display it in the ImageView
        } else {
            Toast.makeText(this, "No image available", Toast.LENGTH_SHORT).show();
        }
    }
}
