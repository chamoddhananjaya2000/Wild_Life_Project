package com.example.wildlife;  // Use your app's package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class guidebooking extends AppCompatActivity {  // Class name should start with uppercase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guidebooking);  // Ensure this matches your XML layout name

        // Button to navigate to Guide Details
        Button selectGuide = findViewById(R.id.select);
        selectGuide.setOnClickListener(v -> {
            Intent intent = new Intent(guidebooking.this, guide.class);
            startActivity(intent);
        });

        // Button to navigate to Jayantha Page
        Button selectJayantha = findViewById(R.id.select1);
        selectJayantha.setOnClickListener(v -> {
            Intent intent = new Intent(guidebooking.this, jayantha.class);
            startActivity(intent);
        });
    }
}
