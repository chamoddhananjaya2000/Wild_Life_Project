package com.example.wildlife;

import android.content.Context;
import android.content.SharedPreferences;

public class UserPreferences {
    private static final String PREF_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_SIGNED_UP = "signedUp";
    private static final String KEY_LOGGED_IN = "loggedIn";

    private static SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public UserPreferences(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // ✅ Fix: Make isLoggedIn() a non-static method
    public static boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_LOGGED_IN, false);
    }

    public void setLoggedIn(boolean loggedIn) {
        editor.putBoolean(KEY_LOGGED_IN, loggedIn);
        editor.apply();
    }

    public void setUsername(String username) {
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    public String getUsername() {
        return sharedPreferences.getString(KEY_USERNAME, "");
    }

    public void setEmail(String email) {
        editor.putString(KEY_EMAIL, email);
        editor.apply();
    }

    public String getEmail() {
        return sharedPreferences.getString(KEY_EMAIL, "");
    }

    // ✅ Fix: Remove static keyword from isSignedUp()
    public static boolean isSignedUp() {
        return sharedPreferences.getBoolean(KEY_SIGNED_UP, false);
    }

    public void setSignedUp(boolean isSignedUp) {
        editor.putBoolean(KEY_SIGNED_UP, isSignedUp);
        editor.apply();
    }
}
