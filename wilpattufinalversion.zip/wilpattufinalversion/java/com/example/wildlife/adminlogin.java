package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class adminlogin extends AppCompatActivity {  // class name changed to AdminLogin

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    // Predefined admin credentials
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_login);

        // Initialize views
        usernameEditText = findViewById(R.id.admin_username);
        passwordEditText = findViewById(R.id.admin_password);
        loginButton = findViewById(R.id.admin_login_button);

        // Set click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get entered username and password
                String enteredUsername = usernameEditText.getText().toString().trim();
                String enteredPassword = passwordEditText.getText().toString().trim();

                // Validate credentials
                if (validateCredentials(enteredUsername, enteredPassword)) {
                    // If valid, navigate to the admin dashboard or main activity
                    Intent intent = new Intent(adminlogin.this, AdminActivity.class);
                    startActivity(intent);
                    finish(); // Close login activity
                } else {
                    // If invalid, show an error message
                    Toast.makeText(adminlogin.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to validate admin credentials
    private boolean validateCredentials(String username, String password) {
        return ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password);
    }
}
