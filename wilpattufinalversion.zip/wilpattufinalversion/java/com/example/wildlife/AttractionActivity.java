package com.example.wildlife;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AttractionActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AttractionAdapter adapter;
    private List<Attraction> attractionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attraction);

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the list of attractions
        attractionList = new ArrayList<>();

        // Load the attraction data into the list
        loadAttractions();

        // Create an adapter and set it to the RecyclerView
        adapter = new AttractionAdapter(attractionList);
        recyclerView.setAdapter(adapter);
    }

    private void loadAttractions() {
        // Add actual attractions with image resources (R.drawable.*)
        attractionList.add(new Attraction("Thambapanni", R.drawable.thambapanni1, "An ancient kingdom believed to be the first settlement of Prince Vijaya."));
        attractionList.add(new Attraction("Weli Wehera", R.drawable.veliwehera1, "A historic Buddhist temple known for its beautiful stupa."));
        attractionList.add(new Attraction("Galge Viharaya", R.drawable.galgewiharaya, "An ancient rock temple with stunning carvings and a peaceful environment."));
        attractionList.add(new Attraction("Kuweni Malige", R.drawable.kuweni1, "The palace ruins of Queen Kuweni, an important figure in Sri Lankan history."));
    }
}
