package com.example.wildlife;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.wildlife.loginpage;

public class ProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 1;
    private ImageView profileImageView;
    private Button btnChangeProfilePic, btnLogout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileImageView = findViewById(R.id.profile_image);
        btnChangeProfilePic = findViewById(R.id.btnChangeProfilePic);
        btnLogout = findViewById(R.id.btnLogout);

        // Open the gallery to select a new profile picture
        btnChangeProfilePic.setOnClickListener(v -> openGallery());

        // Handle Logout action
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, loginpage.class);
            startActivity(intent);
            finish(); // Close the ProfileActivity
        });
    }

    // Open the gallery to pick an image
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            profileImageView.setImageURI(selectedImage);
            Toast.makeText(this, "Profile picture updated!", Toast.LENGTH_SHORT).show();
        }
    }
}
