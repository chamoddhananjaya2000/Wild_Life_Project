package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class calender extends AppCompatActivity {

    // Date selection variables
    private CalendarView calendarView;
    private TextView startDateText, endDateText;
    private boolean isStartDateSelected = true; // Flag to track if start or end date is selected

    // Ticket booking variables
    private TextView ticketQuantityText, totalPriceText;
    private int ticketQuantity = 1; // Default quantity
    private final int pricePerTicket = 80; // Price per ticket

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calender);  // Make sure the XML layout is correct

        // Initialize the views for calendar
        calendarView = findViewById(R.id.calendarView);
        startDateText = findViewById(R.id.startDateText);
        endDateText = findViewById(R.id.endDateText);

        // Initialize the views for ticket booking
        ticketQuantityText = findViewById(R.id.ticketQuantity);
        totalPriceText = findViewById(R.id.total);
        Button btnMinus = findViewById(R.id.btnMinus);
        Button btnPlus = findViewById(R.id.btnPlus);
        Button btnBuyTicket = findViewById(R.id.btnBuyTicket); // Get the Buy Ticket button

        // Update the total price initially
        updateTotalPrice();

        // Set up listener for date selection on the calendar
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // Format the selected date
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, dayOfMonth);

            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
            String selectedDate = dateFormat.format(calendar.getTime());

            // Update start or end date based on the flag
            if (isStartDateSelected) {
                startDateText.setText("Start Date: " + selectedDate);
                isStartDateSelected = false; // Set flag to select end date next
            } else {
                endDateText.setText("End Date: " + selectedDate);
                isStartDateSelected = true; // Reset flag to select start date next
            }
        });

        // Button click listeners for ticket quantity
        btnMinus.setOnClickListener(v -> {
            if (ticketQuantity > 1) {
                ticketQuantity--;
                ticketQuantityText.setText(String.valueOf(ticketQuantity));
                updateTotalPrice();
            }
        });

        btnPlus.setOnClickListener(v -> {
            ticketQuantity++;
            ticketQuantityText.setText(String.valueOf(ticketQuantity));
            updateTotalPrice();
        });

        // Button click listener for Buy Ticket
        btnBuyTicket.setOnClickListener(v -> {
            // Navigate to the login page (LoginActivity)
            Intent intent = new Intent(calender.this, login.class);
            startActivity(intent);
        });
    }

    // Method to update the total price
    private void updateTotalPrice() {
        int totalPrice = ticketQuantity * pricePerTicket;
        totalPriceText.setText("Total\nRS " + totalPrice);
    }
}
