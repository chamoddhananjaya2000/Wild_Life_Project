package com.example.wildlife;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ReportActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1; // Request code for image picker
    private static final int REQUEST_STORAGE_PERMISSION = 2; // Permission request code
    private EditText reportDescription;
    private ImageView imagePreview;
    private Uri imageUri;

    private DatabaseHelper databaseHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report);

        // Initialize views
        reportDescription = findViewById(R.id.report_description);
        imagePreview = findViewById(R.id.image_preview);
        Button btnUploadImage = findViewById(R.id.btn_upload_image);
        Button btnSubmitReport = findViewById(R.id.btn_submit_report);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Check and request permissions if needed
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
        }

        // Open gallery when the button is clicked
        btnUploadImage.setOnClickListener(v -> openGallery());

        // Submit report button
        btnSubmitReport.setOnClickListener(v -> submitReport());
    }

    // Method to open the gallery and pick an image
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*"); // Only allow image selection
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Handle the result of the image picker (after the user selects an image)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // Get the image URI
            imageUri = data.getData();

            // Decode the image to a Bitmap and resize it if necessary
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                // Resize the bitmap if needed
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                int newWidth = 800; // Desired width for the image
                int newHeight = (newWidth * height) / width;
                Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);

                // Display the resized image
                imagePreview.setImageBitmap(resizedBitmap);
                imagePreview.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Submit report method
    private void submitReport() {
        String description = reportDescription.getText().toString().trim();

        if (description.isEmpty()) {
            Toast.makeText(this, "Please enter a report description", Toast.LENGTH_SHORT).show();
            return;
        }

        if (imageUri == null) {
            Toast.makeText(this, "Please upload an image", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert image URI to byte array
        byte[] imageBytes = getImageBytes(imageUri);

        // Save the report to the database
        long result = databaseHelper.addReport(description, imageBytes);

        if (result != -1) {
            // Data is saved successfully, navigate to the AdminActivity
            Toast.makeText(this, "Report submitted successfully", Toast.LENGTH_SHORT).show();

            // Send email to admin (pasindulthambugala@gmail.com)
            sendEmail(description);

            // Send data (description and image) to AdminActivity
            Intent intent = new Intent(ReportActivity.this, AdminActivity.class);
            intent.putExtra("reportDescription", description);
            intent.putExtra("imageBytes", imageBytes);

            // Redirect the user to the homepage
            Intent homepageIntent = new Intent(ReportActivity.this, home.class);
            startActivity(homepageIntent);
            finish();
        } else {
            Toast.makeText(this, "Error saving report", Toast.LENGTH_SHORT).show();
        }
    }

    // Convert image URI to byte array
    private byte[] getImageBytes(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Send email method to notify the admin
    private void sendEmail(String description) {
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:")); // Only email apps should handle this intent
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"pasindulthambugala@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "New Report Submitted");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "A new report has been submitted.\n\nDescription: " + description);

        // Check if there is an email app to handle the intent
        if (emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(emailIntent);
        } else {
            Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show();
        }
    }
}
