package com.example.wildlife;

public class ReportModel {
    private String reportId;
    private String description;
    private String imageUrl;
    private String approvalStatus; // "pending", "approved", or "rejected"

    // Constructor, Getters, and Setters
    public ReportModel(String reportId, String description, String imageUrl, String approvalStatus) {
        this.reportId = reportId;
        this.description = description;
        this.imageUrl = imageUrl;
        this.approvalStatus = approvalStatus;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    // Corrected getId method
    public String getId() {
        return reportId;  // Return the reportId
    }
}
