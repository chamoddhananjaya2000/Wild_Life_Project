package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class sign_up extends AppCompatActivity {

    private EditText etUsername, etEmail, etPassword;
    private Button btnSignUp, btnGoogleSignIn;
    private TextView tvAlreadyHaveAccount;

    private UserPreferences userPreferences;
    private GoogleSignInClient googleSignInClient;
    private static final int RC_SIGN_IN = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnGoogleSignIn = findViewById(R.id.btnGoogleSignIn);
        tvAlreadyHaveAccount = findViewById(R.id.tvAlreadyHaveAccount);

        userPreferences = new UserPreferences(this);

        // Google Sign-In Configuration
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        // Normal Sign-Up
        btnSignUp.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(sign_up.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else if (!isValidEmail(email)) {
                Toast.makeText(sign_up.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            } else if (password.length() < 6) {
                Toast.makeText(sign_up.this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            } else {
                // Save user state
                userPreferences.setSignedUp(true);
                userPreferences.setUsername(username);
                userPreferences.setEmail(email);

                Toast.makeText(sign_up.this, "Sign-up successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(sign_up.this, login.class));
                finish();
            }
        });

        // Google Sign-In
        btnGoogleSignIn.setOnClickListener(v -> signInWithGoogle());

        // Redirect to Login Page
        tvAlreadyHaveAccount.setOnClickListener(v -> {
            startActivity(new Intent(sign_up.this, login.class));
            finish();
        });
    }

    // Google Sign-In process
    private void signInWithGoogle() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    // Handle Google Sign-In result
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    String username = account.getDisplayName();
                    String email = account.getEmail();

                    userPreferences.setSignedUp(true);
                    userPreferences.setUsername(username);
                    userPreferences.setEmail(email);

                    Toast.makeText(sign_up.this, "Google Sign-In successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(sign_up.this, home.class));  // Redirect to home
                    finish();
                }
            } catch (ApiException e) {
                Toast.makeText(sign_up.this, "Google sign-in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Validate email format
    private boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}
