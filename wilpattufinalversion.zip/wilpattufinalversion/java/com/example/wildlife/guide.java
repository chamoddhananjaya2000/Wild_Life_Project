package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class guide extends AppCompatActivity {

    private static final String TAG = "GuideActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide);

        Button bookGuideButton = findViewById(R.id.bookGuideButton);

        // Set click listener using a lambda expression
        bookGuideButton.setOnClickListener(v -> {
            Log.d(TAG, "Book Guide button clicked");
            Toast.makeText(guide.this, "Navigating to login", Toast.LENGTH_SHORT).show();

            // Navigate to LoginActivity
            Intent intent = new Intent(guide.this, login.class);
            startActivity(intent);
        });
    }
}
