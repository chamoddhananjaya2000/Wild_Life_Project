package com.example.wildlife;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class successful extends AppCompatActivity {

    private ImageView imgSuccess;
    private TextView tvSuccessMessage, tvConfirmationMessage;
    private Button btnBackToHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.successful);  // Ensure this XML exists

        imgSuccess = findViewById(R.id.imgSuccess);
        tvSuccessMessage = findViewById(R.id.tvSuccessMessage);
        tvConfirmationMessage = findViewById(R.id.tvConfirmationMessage);
        btnBackToHome = findViewById(R.id.btnBackToHome);

        // Button click listener to go back to the home screen
        btnBackToHome.setOnClickListener(v -> {
            Intent intent = new Intent(successful.this, home.class);  // Replace with actual home activity class name
            startActivity(intent);
            finish();  // Optional: Close this activity to prevent going back to this page
        });
    }
}
